package com.nendrasys.dao;

import com.nendrasys.model.UserRegistration;

import java.util.List;

public interface StudentDao {
    List<UserRegistration> getAllStudents();
    public int updateStudentData(UserRegistration reg);
    UserRegistration getStudentById(int id);
    public int deleteStudentData(int id);
}
