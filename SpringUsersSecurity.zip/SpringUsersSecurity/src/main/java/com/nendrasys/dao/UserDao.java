package com.nendrasys.dao;

import com.nendrasys.model.ChangePassword;
import com.nendrasys.model.UserRegistration;

import java.security.Principal;
import java.util.List;

public interface UserDao {
    public int saveUsersData(UserRegistration reg);
    public List<UserRegistration> getAllUsers();
    public int changePassword(ChangePassword password, Principal principal);
}
