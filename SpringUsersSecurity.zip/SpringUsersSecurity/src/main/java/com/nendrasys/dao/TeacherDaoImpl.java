package com.nendrasys.dao;
import com.nendrasys.model.UserRegistration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class TeacherDaoImpl implements TeacherDao {
    @Autowired
    JdbcTemplate template;

    public JdbcTemplate getTemplate() {
        return template;
    }

    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }

    @Override
    public List<UserRegistration> getAllTeachers() {
        List<UserRegistration> list = template.query("SELECT * FROM users where userRole='ROLE_TEACHER'", new RowMapper<UserRegistration>() {
            @Override
            public UserRegistration mapRow(ResultSet resultSet, int i) throws SQLException {
                UserRegistration userRegistration = new UserRegistration();
                userRegistration.setId(resultSet.getInt("id"));
                userRegistration.setName(resultSet.getString("name"));
                userRegistration.setAge(resultSet.getInt("age"));
                userRegistration.setUsername(resultSet.getString("username"));
                userRegistration.setPassword(resultSet.getString("password"));
                userRegistration.setPhoneNumber(resultSet.getString("phoneNumber"));
                userRegistration.setState(resultSet.getString("state"));
                userRegistration.setUserRole(resultSet.getString("userRole"));
                /*userRegistration.setEnabled(resultSet.getInt("enabled"));*/
                return userRegistration;
            }
        });
        return list;
    }

    @Override
    public int updateTeacherData(UserRegistration reg) {
        String query = "update users set id='"+reg.getId()+"',name='"+reg.getName()+"',age='"+reg.getAge()+"',phoneNumber='"+reg.getPhoneNumber()+"',state='"+reg.getState()+"' where id='"+reg.getId()+"'";
        return template.update(query);
    }

    @Override
    public UserRegistration getTeacherById(int id) {
        UserRegistration userRegistration = (UserRegistration) template.queryForObject("SELECT * FROM users where id=?", new BeanPropertyRowMapper(UserRegistration.class), id);
        return userRegistration;
    }

    @Override
    public int deleteTeacherData(int id) {
        String query = "delete from users where id="+id+"";
        return template.update(query);
    }
}
