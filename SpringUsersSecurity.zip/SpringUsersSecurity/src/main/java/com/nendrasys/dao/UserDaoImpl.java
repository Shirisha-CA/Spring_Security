package com.nendrasys.dao;

import com.nendrasys.model.ChangePassword;
import com.nendrasys.model.UserRegistration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.security.Principal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class UserDaoImpl implements UserDao {
    @Autowired
    JdbcTemplate template;

    public JdbcTemplate getTemplate() {
        return template;
    }

    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }

    @Override
    public int saveUsersData(UserRegistration userRegistration) {
        String sql = "insert into users(id,name,age,username, password,phoneNumber,state,userRole,enabled) values('"+userRegistration.getId()+"','"+userRegistration.getName()+"'," +
                "'"+userRegistration.getAge()+"','"+userRegistration.getUsername()+"','"+userRegistration.getPassword()+"'," +
                "'"+userRegistration.getPhoneNumber()+"','"+userRegistration.getState()+"','"+userRegistration.getUserRole()+"','"+userRegistration.getEnabled()+"')";
        return template.update(sql);

    }

    @Override
    public List<UserRegistration> getAllUsers() {
        List<UserRegistration> list = template.query("SELECT * FROM users where userRole='ROLE_STUDENT' or userRole='ROLE_TEACHER'", new RowMapper<UserRegistration>() {
            @Override
            public UserRegistration mapRow(ResultSet resultSet, int i) throws SQLException {
                UserRegistration userRegistration = new UserRegistration();
                userRegistration.setId(resultSet.getInt("id"));
                userRegistration.setName(resultSet.getString("name"));
                userRegistration.setAge(resultSet.getInt("age"));
                userRegistration.setUsername(resultSet.getString("username"));
                userRegistration.setPassword(resultSet.getString("password"));
                userRegistration.setPhoneNumber(resultSet.getString("phoneNumber"));
                userRegistration.setState(resultSet.getString("state"));
                userRegistration.setUserRole(resultSet.getString("userRole"));
                /* userRegistration.setEnabled(resultSet.getInt("enabled"));*/
                return userRegistration;
            }
        });
        return list;
    }

    @Override
    public int changePassword(ChangePassword password, Principal principal) {
        String query=null;
        if(password.getOldPassword().equals(password.getNewPassword()))
        {
            return 0;
        }
        else if(password.getNewPassword().equals(password.getConfirmNewPassword())){
            query = "update users set password='"+password.getNewPassword()+"' where password='"+password.getOldPassword()+"' and username='"+principal.getName()+"'";
        }
        return template.update(query);
    }
}
