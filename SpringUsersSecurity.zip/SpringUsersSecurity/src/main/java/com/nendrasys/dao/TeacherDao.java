package com.nendrasys.dao;

import com.nendrasys.model.UserRegistration;

import java.util.List;

public interface TeacherDao {
    List<UserRegistration> getAllTeachers();
    public int updateTeacherData(UserRegistration reg);
    UserRegistration getTeacherById(int id);
    public int deleteTeacherData(int id);
}
