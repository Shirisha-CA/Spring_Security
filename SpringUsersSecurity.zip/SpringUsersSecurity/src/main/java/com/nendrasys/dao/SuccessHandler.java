package com.nendrasys.dao;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import java.io.IOException;
import java.util.Collection;

@Component("successHandler")
public class SuccessHandler implements AuthenticationSuccessHandler {
    private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();
    @Override
    public void onAuthenticationSuccess(javax.servlet.http.HttpServletRequest httpServletRequest, javax.servlet.http.HttpServletResponse httpServletResponse, Authentication authentication)
            throws IOException, ServletException {
        boolean hasStudRole = false;
        boolean hasTeachRole = false;
        boolean hasAdminRole = false;
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
       /* System.out.println(authentication.);*/
        for (GrantedAuthority grantedAuthority : authorities) {
            if (grantedAuthority.getAuthority().equals("ROLE_STUDENT")) {
                hasStudRole = true;
                break;
            } else if (grantedAuthority.getAuthority().equals("ROLE_TEACHER")) {
                hasTeachRole = true;
                break;
            }else if(grantedAuthority.getAuthority().equals("ROLE_ADMIN")){
                hasAdminRole = true;
            }
        }

        if (hasStudRole) {
            redirectStrategy.sendRedirect(httpServletRequest, httpServletResponse, "/studentList");
        } else if (hasTeachRole) {
            redirectStrategy.sendRedirect(httpServletRequest, httpServletResponse, "/teacherList");
        } else if (hasAdminRole) {
            redirectStrategy.sendRedirect(httpServletRequest, httpServletResponse, "/usersList");
        }
        else {
            throw new IllegalStateException();
        }
    }
}
