package com.nendrasys.service;

import com.nendrasys.dao.UserDao;
import com.nendrasys.model.ChangePassword;
import com.nendrasys.model.UserRegistration;
import org.springframework.beans.factory.annotation.Autowired;

import java.security.Principal;

public class UserServiceImpl implements UserService {
    @Autowired
    UserDao userDao;

    @Override
    public String saveUsersData(UserRegistration reg) {
        int count=0;
        count=userDao.saveUsersData(reg);
        if(count==1){
            return "Registered User Successfully";
        }
        else{
            return "Registration is not done";
        }
    }

    @Override
    public String changePassword(ChangePassword password, Principal principal) {
        int count=0;
        count=userDao.changePassword(password,principal);
        if(count==1){
            return "Password is changed Successfully";
        }
        else{
            return "Password is not Changed";
        }
    }
}
