package com.nendrasys.service;

import com.nendrasys.model.ChangePassword;
import com.nendrasys.model.UserRegistration;

import java.security.Principal;
import java.util.List;

public interface UserService {
    public String saveUsersData(UserRegistration reg);
    public String changePassword(ChangePassword password, Principal principal);
}
