package com.nendrasys.controller;

import com.nendrasys.dao.TeacherDao;
import com.nendrasys.model.UserRegistration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;

@Controller("/TeacherController")
public class TeacherController {
    @Autowired
    TeacherDao teacherDao;

    @RequestMapping(value = "/teacherList")
    public String showAllStudent(Model model){
        List<UserRegistration> students = teacherDao.getAllTeachers();
        model.addAttribute("listOfTeachers",students);
        return "teacherDashboard";
    }

    @RequestMapping(value = "/updateTeacher/{id}",method = RequestMethod.GET)
    public String showHome1(Model model,@PathVariable(value = "id") int id){
        UserRegistration reg = teacherDao.getTeacherById(id);
        model.addAttribute("reg",reg);
        model.addAttribute("reg",teacherDao.getTeacherById(id));
        return "updateTeacherDetails";
    }

    @RequestMapping(value="/updateTeacherData", method = RequestMethod.POST)
    public String updateStudentData(@ModelAttribute("reg") UserRegistration reg, Model model){
        model.addAttribute("result",teacherDao.updateTeacherData(reg));
        return "updateSuccess2";
    }

    @RequestMapping("/deleteTeacherData/{id}")
    public String deleteStudentById(Model model, @PathVariable(value = "id") int id){
        model.addAttribute("delmsg2",teacherDao.deleteTeacherData(id));
        return "deleteSuccess2";
    }

    @ModelAttribute("sataesList")
    public List<String> stateList() {
        List<String> states = new ArrayList<String>();
        states.add("Telangana");
        states.add("Tamilnadu");
        states.add("Karnataka");
        states.add("Maharashta");
        states.add("Kerala");
        return states;
    }
}
