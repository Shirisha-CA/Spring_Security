package com.nendrasys.controller;

import com.nendrasys.dao.StudentDao;
import com.nendrasys.model.UserRegistration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;

@Controller("/StudentController")
public class StudentController {
    @Autowired
    StudentDao studentDao;
    @RequestMapping(value = "/studentList")
    public String showAllStudent(Model model){
        List<UserRegistration> students = studentDao.getAllStudents();
        model.addAttribute("listOfStudents",students);
        return "studentDashboard";
    }

    @RequestMapping(value = "/updateStudent/{id}",method = RequestMethod.GET)
    public String showHome1(Model model,@PathVariable(value = "id") int id){
        UserRegistration reg = studentDao.getStudentById(id);
        model.addAttribute("reg",reg);
        return "updateStudentDetails";
    }

    @RequestMapping(value="/updateStudentData", method = RequestMethod.POST)
    public String updateStudentData(@ModelAttribute("reg") UserRegistration reg, Model model){
        model.addAttribute("result",studentDao.updateStudentData(reg));
        return "updateSuccess1";
    }

    @RequestMapping("/deleteStudentData/{id}")
    public String deleteStudentById(Model model, @PathVariable(value = "id") int id){
        model.addAttribute("delmsg1",studentDao.deleteStudentData(id));
        return "deleteSuccess1";
    }

    @ModelAttribute("sataesList")
    public List<String> stateList() {
        List<String> states = new ArrayList<String>();
        states.add("Telangana");
        states.add("Tamilnadu");
        states.add("Karnataka");
        states.add("Maharashta");
        states.add("Kerala");
        return states;
    }
}
