package com.nendrasys.controller;

import com.nendrasys.dao.StudentDao;
import com.nendrasys.dao.UserDao;
import com.nendrasys.model.ChangePassword;
import com.nendrasys.model.UserRegistration;
import com.nendrasys.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@Controller("/UserRegistrationController")
public class UserRegistrationController {
    @Autowired
    private UserDao userDao;

    @Autowired
    private UserService userService;


    @RequestMapping(value = "/usersRegister",method = RequestMethod.GET)
    public String getStudentRegisterForm(Model model){
            UserRegistration registration = new UserRegistration();
            model.addAttribute("regs", registration);
            return "usersRegistration";
    }

    @RequestMapping(value = "/usersReg" , method = RequestMethod.POST)
    public String registerUser(@ModelAttribute("reg") UserRegistration reg , Model model){
        String resultMsg = null;
        resultMsg = userService.saveUsersData(reg);
        model.addAttribute("result",resultMsg);
        return "regSuccess";
    }

   /* @RequestMapping(value = "/usersReg", method = RequestMethod.POST)
    public ModelAndView registerThestudent(ModelAndView mv,
                                           @RequestParam("id") int id,
                                           @RequestParam("name") String name,
                                           @RequestParam("age") int age,
                                           @RequestParam("username") String username,
                                           @RequestParam("password") String password,
                                           @RequestParam("phoneNumber") String phoneNumber,
                                           @RequestParam("state") String state,
                                           @RequestParam("userRole") String userRole,
                                           @RequestParam("enabled") int enabled) {
        UserRegistration registration = new UserRegistration();
        registration.setId(id);
        registration.setName(name);
        registration.setAge(age);
        registration.setUsername(username);
        registration.setPassword(password);
        registration.setPhoneNumber(phoneNumber);
        registration.setState(state);
        registration.setUserRole(userRole);
        registration.setEnabled(enabled);
        userDao.saveUsersData(registration);
        mv.setViewName("regSuccess");
        return mv;
    }*/

    @ModelAttribute("sataesList")
    public List<String> stateList() {
        List<String> states = new ArrayList<String>();
        states.add("Telangana");
        states.add("Tamilnadu");
        states.add("Karnataka");
        states.add("Maharashta");
        states.add("Kerala");
        return states;
    }

    @ModelAttribute("roles")
    public List<String> roleList() {
        List<String> roles = new ArrayList<String>();
        roles.add("ROLE_STUDENT");
        roles.add("ROLE_TEACHER");
        return roles;
    }
}