package com.nendrasys.controller;

import com.nendrasys.dao.UserDao;
import com.nendrasys.model.ChangePassword;
import com.nendrasys.model.UserRegistration;
import com.nendrasys.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.security.Principal;
import java.util.List;
@Controller
public class UserController {
    @Autowired
    UserDao userDao;
    @Autowired
    UserService userService;

    @RequestMapping(value = "/usersList")
    public String showAllStudent(Model model){
        List<UserRegistration> users = userDao.getAllUsers();
        model.addAttribute("listOfUsers",users);
        return "usersDashboard";
    }


    @RequestMapping(value = "/pwdChange", method = RequestMethod.POST)
    public ModelAndView changePassword(ModelAndView mv,
                                       @RequestParam("oldPassword") String oldPassword,
                                       @RequestParam("newPassword") String newPassword,
                                       @RequestParam("confirmNewPassword") String confirmNewPassword)
    {
        ChangePassword changePassword = new ChangePassword();
        changePassword.setOldPassword(oldPassword);
        changePassword.setNewPassword(newPassword);
        changePassword.setConfirmNewPassword(confirmNewPassword);
        return mv;
    }

    @RequestMapping(value = "/changePassword",method = RequestMethod.GET)
    public String showHome1(Model model){
        ChangePassword changePassword = new ChangePassword();
        model.addAttribute("reg1",changePassword);
        //del.addAttribute("reg",userDao.gatUserByUsername(username));
        return "changePassword";
    }

    @RequestMapping(value="/changePassword1", method = RequestMethod.POST)
    public ModelAndView updateStudentData(@ModelAttribute("reg1") ChangePassword password, Principal principal, ModelMap model) {
        String result = null;
        result = userService.changePassword(password, principal);
        model.addAttribute("result", result);
        if (result.contains("Password is changed Successfully")) {
            return new ModelAndView("redirect:/logout", model);
        }
        else{
            return new ModelAndView("pwdChangeSuccess", model);
        }

    }
}
 